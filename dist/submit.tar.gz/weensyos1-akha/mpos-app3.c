#include "mpos-app.h"
#include "lib.h"

/*****************************************************************************
 * mpos-app3
 *
 *   This application is meant to implement the code for Exercise 5.
 *     1. The code uses only local variables.
 *     2. In a system with correct process isolation, the code would print "10".
 *     3. In MiniprocOS, the code would print "11".
 *
 *****************************************************************************/
 
 void start(void) {
        int x = 0;  /* note that local variable x lives on the stack */
        /* YOUR CODE HERE */
        pid_t p = sys_fork();
        if (p == 0)
                /* YOUR CODE HERE */;
        else if (p > 0)
                sys_wait(p); // assume blocking implementation
        app_printf("%d", x);
        sys_exit(0);
}